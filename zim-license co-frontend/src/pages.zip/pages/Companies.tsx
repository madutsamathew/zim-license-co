import { useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Edit, Trash2, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Companies = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  const companies = [
    {
      id: 1,
      name: "TeleCom Solutions Ltd",
      email: "info@telecom.com",
      contactPerson: "John Smith",
      address: "123 Main St, Capital City",
      licenses: 2,
      status: "Active",
    },
    {
      id: 2,
      name: "Radio Wave Broadcasting",
      email: "contact@radiowave.com",
      contactPerson: "Sarah Johnson",
      address: "456 Radio Ave, Metro City",
      licenses: 1,
      status: "Active",
    },
    {
      id: 3,
      name: "Mobile Connect Inc",
      email: "admin@mobileconnect.com",
      contactPerson: "Michael Chen",
      address: "789 Wireless Blvd, Tech Park",
      licenses: 3,
      status: "Active",
    },
  ];

  const handleEdit = (id: number) => {
    toast({ title: "Edit company", description: `Editing company ID: ${id}` });
  };

  const handleDelete = (id: number) => {
    toast({ 
      title: "Delete company", 
      description: `Are you sure you want to delete this company?`,
      variant: "destructive"
    });
  };

  const handleView = (id: number) => {
    toast({ title: "View company", description: `Viewing company ID: ${id}` });
  };

  return (
    <DashboardLayout userRole="regulator">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Companies</h1>
            <p className="text-muted-foreground">
              Manage licensed companies and their information
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Company
          </Button>
        </div>

        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Registered Companies</CardTitle>
            <CardDescription>
              View and manage all companies in the system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search companies..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Company Name</TableHead>
                    <TableHead>Contact Person</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Address</TableHead>
                    <TableHead className="text-center">Licenses</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {companies.map((company) => (
                    <TableRow key={company.id}>
                      <TableCell className="font-medium">{company.name}</TableCell>
                      <TableCell>{company.contactPerson}</TableCell>
                      <TableCell>{company.email}</TableCell>
                      <TableCell>{company.address}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="secondary">{company.licenses}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="default">{company.status}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleView(company.id)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(company.id)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(company.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default Companies;
