import { useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Edit, Trash2, Eye, Calculator, GitCompare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Licenses = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  const licenses = [
    {
      id: 1,
      company: "TeleCom Solutions Ltd",
      type: "CTL",
      issueDate: "2023-01-15",
      expiryDate: "2038-01-15",
      applicationFee: "$800",
      licenseFee: "$100,000,000",
      status: "Active",
      yearsRemaining: 13,
    },
    {
      id: 2,
      company: "Radio Wave Broadcasting",
      type: "PRSL",
      issueDate: "2019-06-20",
      expiryDate: "2029-06-20",
      applicationFee: "$350",
      licenseFee: "$2,000,000",
      status: "Active",
      yearsRemaining: 4,
    },
    {
      id: 3,
      company: "Mobile Connect Inc",
      type: "CTL",
      issueDate: "2010-11-30",
      expiryDate: "2025-11-30",
      applicationFee: "$800",
      licenseFee: "$100,000,000",
      status: "Expiring Soon",
      yearsRemaining: 0.9,
    },
  ];

  const calculateExpiry = (id: number) => {
    const license = licenses.find(l => l.id === id);
    toast({ 
      title: "License Expiry Calculation", 
      description: `${license?.company} license expires in ${license?.yearsRemaining} years`,
    });
  };

  return (
    <DashboardLayout userRole="regulator">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Licenses</h1>
            <p className="text-muted-foreground">
              Manage telecommunications licenses (CTL & PRSL)
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2">
              <GitCompare className="h-4 w-4" />
              Compare Licenses
            </Button>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Issue License
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className="shadow-md border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                CTL Licenses
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">85</div>
              <p className="text-xs text-muted-foreground mt-1">
                15-year validity period
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-md border-secondary/20 bg-gradient-to-br from-secondary/5 to-transparent">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                PRSL Licenses
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">102</div>
              <p className="text-xs text-muted-foreground mt-1">
                Variable validity period
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-md border-warning/20 bg-gradient-to-br from-warning/5 to-transparent">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Expiring Soon
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground mt-1">
                Within 90 days
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Active Licenses</CardTitle>
            <CardDescription>
              View and manage all issued licenses
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search licenses..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Company</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Issue Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead>Application Fee</TableHead>
                    <TableHead>License Fee</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {licenses.map((license) => (
                    <TableRow key={license.id}>
                      <TableCell className="font-medium">{license.company}</TableCell>
                      <TableCell>
                        <Badge variant={license.type === "CTL" ? "default" : "secondary"}>
                          {license.type}
                        </Badge>
                      </TableCell>
                      <TableCell>{license.issueDate}</TableCell>
                      <TableCell>{license.expiryDate}</TableCell>
                      <TableCell>{license.applicationFee}</TableCell>
                      <TableCell>{license.licenseFee}</TableCell>
                      <TableCell>
                        <Badge
                          variant={license.status === "Active" ? "default" : "destructive"}
                        >
                          {license.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => calculateExpiry(license.id)}
                            title="Calculate expiry"
                          >
                            <Calculator className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="View details">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Edit">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Delete">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default Licenses;
